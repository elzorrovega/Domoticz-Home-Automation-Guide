#!/bin/bash
# This script shows the log for both cron and domotics
echo "********"
echo "CRON LOG"
echo ""
grep CRON /var/log/syslog
echo ""
echo "***********"
echo "CLCACHE.SH LOG"
echo ""
grep clcache.sh /var/log/syslog
echo ""
echo "***********"
echo "Domoticz LOG"
echo ""
grep domoticz /var/log/syslog


