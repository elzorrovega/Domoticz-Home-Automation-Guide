#!/bin/bash
#Read RPI uptime and temperature
#Use top for general overview of CPU LOAD % RAM usage
#Use head command is extracts the first 5 lines
#Must set decimal separator to decimal so that mawk works properly
#MAWK CVS format output: rpiuptime, rpicpu(5min), rpiRAM, rpiSWAP, rpitemp
#rpiup=$(uptime -s)
#temp=$(vcgencmd measure_temp | egrep -o '[0-9]*\.[0-9]*')
#ssize=$(egrep CONF_SWAPSIZE /etc/dphys-swapfile | egrep -o '[0-9]*')
#Get Swapsize in the event that swapoff -a is set
#LC_ALL="C" top -b -n 1 | head -n 5 | mawk -v rpiup="$rpiup" -v temp="$temp" -v ssize=$ssize '
#				BEGIN{	{printf ("%19s",rpiup)}
#						{printf("%c",",")}
#				}
#				/load average/ {printf ("%3.1f", substr($13,1,length($13)-1)*100)}
#				/load average/ {printf("%c",",")}
#				/MiB Mem/ {printf ("%3.1f",$8/$4*100)}
#				/MiB Mem/{printf("%c",",")}
#				/MiB Swap/{printf("%3.1f",$7/ssize*100)}
#				/MiB Swap/{printf("%c",",")}
#				END{{printf("%3.1f\n",temp)}}
#				'
DHOST=192.168.1.30:8080
MESSAGE='Hello+DOMOTICZ'
lnormal=1
lstatus=2
lerror=4
lall=268435455
LASTLOGTIME=0
LEVEL=$lnormal
LOGLEVEL=$lall
IDX_Chamber_1_Siren=7
IDX_Hall_Siren=22
IDX_Fibaro_Wall_Plug_1=1
# Retrieve Status for these Sirens and Wall Plug
#Chamber_1_Siren=$(curl -s 'http://'$DHOST'/json.htm?type=devices&rid='$IDX_Chamber_1_Siren'' | mawk '/Status/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"Status" : /,""); gsub(/"/,""); gsub(/,/,"") ; print }')
#echo $Chamber_1_Siren
#Hall_Siren=$(curl -s 'http://'$DHOST'/json.htm?type=devices&rid='$IDX_Hall_Siren'' | mawk '/Status/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"Status" : /,""); gsub(/"/,""); gsub(/,/,"") ; print }')
#echo $Hall_Siren
# Turn Off Wall Plug
curl -s 'http://'$DHOST'/json.htm?type=command&param=switchlight&idx='$IDX_Fibaro_Wall_Plug_1'&switchcmd=Off'
curl -s 'http://'$DHOST'/json.htm?type=command&param=switchlight&idx='$IDX_Chamber_1_Siren'&switchcmd=Off'
curl -s 'http://'$DHOST'/json.htm?type=command&param=switchlight&idx='$IDX_Hall_Siren'&switchcmd=Off'
#curl -s 'http://'$DHOST'/json.htm?type=devices&rid='$IDX_Fibaro_Wall_Plug_1''
#curl -s 'http://'$DHOST'/json.htm?type=devices&rid='$IDX_Fibaro_Wall_Plug_1'' | mawk '/Status/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"Status" : /,""); gsub(/"/,""); gsub(/,/,"") ; print }'

