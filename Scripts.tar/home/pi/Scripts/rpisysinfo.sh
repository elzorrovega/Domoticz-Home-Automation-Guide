#!/bin/bash
#Read RPI & Domoticz System Information
#
DHOST=192.168.1.30:8080
if [ "$#" != "1" ]; then
	curl -s 'http://'$DHOST'/json.htm?type=command&param=getversion' | mawk 'BEGIN {print ("DOMOTICZ Information")}/build_time/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"/,""); gsub(/,/,"") ; print} /hash/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"/,""); gsub(/,/,"") ; print} /version/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"/,""); gsub(/,/,"") ; print} END {print("\n"); print("RASPBERRY Pi Information")}'
	cat /proc/version
	cat /proc/cpuinfo
	for codec in H264 MPG2 WVC1 MPG4 MJPG WMV9 ; do \
	echo -e "$codec:\t$(vcgencmd codec_enabled $codec)"; \
	done
else
		curl -s 'http://'$DHOST'/json.htm?type=command&param=getversion' | mawk 'BEGIN {print ("DOMOTICZ Information")}/build_time/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"/,""); gsub(/,/,"") ; print} /hash/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"/,""); gsub(/,/,"") ; print} /version/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"/,""); gsub(/,/,"") ; print} END {print("\n"); print("RASPBERRY Pi Information")}' > "$1"
	cat /proc/version >> "$1"
	cat /proc/cpuinfo >> "$1"
	for codec in H264 MPG2 WVC1 MPG4 MJPG WMV9 ; do \
	echo -e "$codec:\t$(vcgencmd codec_enabled $codec)" >> "$1" ; \
	done
fi
exit


