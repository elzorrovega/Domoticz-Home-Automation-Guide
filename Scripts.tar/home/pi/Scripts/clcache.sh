#!/bin/bash
# 14/11/2020
# 24/08/2022
# After reading articles about Linux Kernel memory management, it seems caches are useful to system performance.
# Will temporarily suspend them to see the effect. 
# El Zorro
# Script meant to Clear Cache Memory
# If you are using firefox as web browser,open page about:memory and press Minimize memory usage
# echo "restart lxpanel"
# lxpanelctl restart old command
# Updated following Erem's recommendation from 12/12/2020
# sleep 2s
DISPLAY=":0.0" lxpanelctl restart 2>&1
sleep 5s
# echo "Clear Cache Memory in Use"
# 1 Freeing Up the Page Cache
# sudo sh -c "echo 1 > /proc/sys/vm/drop_caches"
# sleep 2s
# 2. Freeing Up the Dentries and Inodes
# sudo sh -c  "echo 2 > /proc/sys/vm/drop_caches"
# sleep 2s
# 3. Freeing Up the Page Cache, Dentries and Inodes
# sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"
# sleep 2s
# 4. Flushing the File System Buffers
# sync
# sleep 2s
sudo swapoff -a
sleep 2s
# Send msg to /var/log/syslog file
# sudo logger "clcache.sh executed"
