#!/bin/bash
# 25/06/22
# Script backs-up the directories & files mention below.
# Using a memory stick as destination folder
#
DEST_FOLDER='/media/pi/LKingston/backup'
DEST_FILE="backup-$(date +'%F_%R').tar"
BACKUP_CMD='/bin/tar -rvf'
BACKUP_CMD2='/bin/cp -rvf'
#
# sudo /bin/rm $DEST_FOLDER/$DEST_FILE.gz
# $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /etc/app1/file1.conf
# 
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Desktop
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Documents
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Downloads
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Music
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Pictures
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Public
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Scripts
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Sound
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/store
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Templates
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Videos
sudo /bin/gzip $DEST_FOLDER/$DEST_FILE
sudo $BACKUP_CMD2 /home/pi/Documents/bookmarks_19_03_2023.html $DEST_FOLDER
sudo $BACKUP_CMD2 /home/pi/Documents/elzorrobookmarks.html $DEST_FOLDER
sudo $BACKUP_CMD2 /home/pi/Documents/DomoticzDiary $DEST_FOLDER


