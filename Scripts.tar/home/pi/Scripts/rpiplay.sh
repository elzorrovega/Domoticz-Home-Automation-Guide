#!/bin/bash
#30/04/22
#Script uses RPiPlay to mirror iOS onto RaspberryPi.

/home/pi/RPiPlay/build/rpiplay -n Monitor -a hdmi

