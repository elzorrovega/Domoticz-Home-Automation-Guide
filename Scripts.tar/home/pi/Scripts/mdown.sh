#!/bin/bash
echo "First stop Monit"
#
sudo /etc/init.d/monit stop 
#
echo "Then stop Domoticz"
#
sudo /etc/init.d/domoticz.sh stop
#
echo "When you are done modifying/updating/whatever, start Domoticz first:"
#
echo "Start Domoticz"
echo "sudo /etc/init.d/domoticz.sh start"
#
echo "Then start Monit again"
#
echo "sudo /etc/init.d/monit start"
#



