#!/bin/bash
# Find IP/MAC of ethernet devices
#if [ -e /sys/class/net/eth0 ]; then
#    MACe=$(cat /sys/class/net/eth0/address)
#    echo $MACe
#else
#    MACw=$(cat /sys/class/net/wlan0/address)
#    echo $MACw
#fi
#ifconfig eth0 | grep 'eth0' 
#ifconfig eth0 | grep 'ether'
#ifconfig wlan0 | grep 'wlan0'
#ifconfig wlan0 | grep 'inet'
#
date
Rasp=$(hostname)
echo $Rasp "IP Configuration" 
RaspIP=$(hostname -I)
echo "IP " $RaspIP
MACe=$(cat /sys/class/net/eth0/address)
echo "eth0 MAC" $MACe
MACw=$(cat /sys/class/net/wlan0/address)
echo "wlan0 MAC" $MACw
echo "Is Domoticz Daemon running?"
ps -ef | grep 'domoticz'
#
