#!/bin/bash

# sqlite3 hold.db 'select distinct target from hold target'
cd /home/pi/Scripts
ls *db
read -p "Enter database to review ie. base.db " base
sqlite3 "$base" '.schema'
read -p "Enter table to show " mesa
read -p "Enter search column for tag " col1 tag
if [ -n "$tag" ]; then
sqlite3 "$base" << EOS
.mode column
select * from "$mesa" where "$col1" like "%$tag%";
EOS
fi
exit
