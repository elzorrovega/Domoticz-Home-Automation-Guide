#!/bin/bash
#This script will stop ahavi serviced and Deamon usd for RPIPlay for it may be at the origin of the codec crash
sudo systemctl disable avahi-daemon.socket
sudo systemctl disable avahi-daemon.service
#
