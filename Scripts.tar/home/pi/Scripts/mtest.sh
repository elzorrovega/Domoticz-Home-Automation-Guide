#!/bin/bash
# Enter Tab as Field Separator to PS output to allow easier EXCEl import
# Format file printed with old pstruc.sh 
if [ "$#" != "2" ]; then
	mawk 'OFS="\t"{if (NR < 6) print $0} {if (NR > 6) print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11}' "$1"
else
	
	mawk 'OFS="\t"{if (NR < 6) print $0} {if (NR > 6) print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11}' "$1" >> "$2"
fi
exit
