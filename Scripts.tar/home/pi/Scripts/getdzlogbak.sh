#!/bin/bash
# Script is to get log files from Domoticz when security alarm is tripped
# El Zorro 30/07/22
#
# /json.htm?type=command&param=getlog&lastlogtime=LASTLOGTIME&loglevel=LOGLEVEL
# LOGLEVEL 1 = normal
#          2 = status
#          4 = error
#  268435455 = all
#
DHOST=192.168.1.30:8080
MESSAGE='Hello+DOMOTICZ'
lnormal=1
lstatus=2
lerror=4
lall=268435455
LASTLOGTIME=0
LEVEL=$lnormal
LOGLEVEL=$lall
IDX_Chamber_1_Siren=7
IDX_Hall_Siren=22
#
Chamber_1_Siren=$(curl -s 'http://'$DHOST'/json.htm?type=devices&rid='$IDX_Chamber_1_Siren'' | mawk '/Status/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"Status" : /,""); gsub(/"/,""); gsub(/,/,"") ; print }')
#echo $Chamber_1_Siren
Hall_Siren=$(curl -s 'http://'$DHOST'/json.htm?type=devices&rid='$IDX_Hall_Siren'' | mawk '/Status/ { gsub (/^[ \t]+|[ \t]+$/, ""); gsub(/"Status" : /,""); gsub(/"/,""); gsub(/,/,"") ; print }')
#echo $Hall_Siren
#
if [ "$Chamber_1_Siren" == "On" ] || [ "$Hall_Siren" == "On" ] ; then
	date_now=$(date +"%Y%m%d%H%M")
	#curl -s 'http://192.168.1.30:8080/json.htm?type=command&param=addlogmessage&message='Hello+DOMOTICZ'&level=1'
	curl -s 'http://'$DHOST'/json.htm?type=command&param=addlogmessage&message='$MESSAGE'&level='$LEVEL''
	if [ "$#" != "1" ]; then
	#curl -s 'http://192.168.1.30:8080/json.htm?type=command&param=getlog&lastlogtime=0&loglevel=268435455'
	curl -s 'http://'$DHOST'/json.htm?type=command&param=getlog&lastlogtime='$LASTLOGTIME'&loglevel='$LOGLEVEL'' | mawk -f /home/pi/Scripts/dzlog
	else
	curl -s 'http://'$DHOST'/json.htm?type=command&param=getlog&lastlogtime='$LASTLOGTIME'&loglevel='$LOGLEVEL'' | mawk -f /home/pi/Scripts/dzlog > "$1$date_now"
	fi
fi
exit

