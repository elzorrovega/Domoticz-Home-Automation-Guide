#!/usr/bin/env bash

### Colors ##
ESC=$(printf '\033') RESET="${ESC}[0m" BLACK="${ESC}[30m" RED="${ESC}[31m"
GREEN="${ESC}[32m" YELLOW="${ESC}[33m" BLUE="${ESC}[34m" MAGENTA="${ESC}[35m"
CYAN="${ESC}[36m" WHITE="${ESC}[37m" DEFAULT="${ESC}[39m"

### Color Functions ##

greenprint() { printf "${GREEN}%s${RESET}\n" "$1"; }
blueprint() { printf "${BLUE}%s${RESET}\n" "$1"; }
redprint() { printf "${RED}%s${RESET}\n" "$1"; }
yellowprint() { printf "${YELLOW}%s${RESET}\n" "$1"; }
magentaprint() { printf "${MAGENTA}%s${RESET}\n" "$1"; }
cyanprint() { printf "${CYAN}%s${RESET}\n" "$1"; }
fn_bye() { echo "Bye bye."; exit 0; }
fn_fail() { echo "Wrong option." exit 1; }
fn_vdb()
{
cd /home/pi/Scripts
echo -ne "
$(blueprint '*********************')
"
ls *db
echo -ne "
$(blueprint '*********************')
"
read -p "$(cyanprint 'Enter database to review ie. base.db') " base
sqlite3 "$base" '.schema'
echo -ne "
$(blueprint '*********************')
"
read -p "$(cyanprint 'Enter table to show') " mesa
echo -ne "
$(blueprint '*********************')
"
read -p "$(cyanprint 'Enter max 3 columns or null to print table') " col1 col2 col3
echo -ne "
$(blueprint '*********************')
"
if [[ -n "$col1" && -n "$col2" && -n "$col3" ]]; then 
sqlite3 "$base" << EOS
.mode column
select "$col1", "$col2", "$col3" from "$mesa";
EOS
elif [[ -n "$col1" && -n "$col2" ]]; then
sqlite3 "$base" << EOS
.mode column
select "$col1", "$col2" from "$mesa";
EOS
elif [ -n "$col1" ]; then
sqlite3 "$base" << EOS
.mode column
select "$col1" from "$mesa";
EOS
else
sqlite3 "$base" "select * from "$mesa"";
fi
}
#
fn_sdb()
{
cd /home/pi/Scripts
echo -ne "
$(blueprint '*********************')
"
ls *db
read -p "$(cyanprint 'Enter database to review ie. base.db') " base
echo -ne "
$(blueprint '*********************')
"
sqlite3 "$base" '.schema'
echo -ne "
$(blueprint '*********************')
"
read -p "$(cyanprint 'Enter table to show') " mesa
echo -ne "
$(blueprint '*********************')
"
read -p "$(cyanprint 'Enter column & tag to search for') " col1 tag
echo -ne "
$(blueprint '*********************')
"
if [ -n "$tag" ]; then
sqlite3 "$base" << EOS
.mode column
select * from "$mesa" where "$col1" like "%$tag%";
EOS
fi
}
#
submenu() {
    echo -ne "
$(cyanprint 'SUBMENU')
$(greenprint '1)') View Databases
$(greenprint '2)') Search Database
$(magentaprint '3)') Go Back to Main Menu
$(redprint '0)') Exit
Choose an option:  "
    read -r ans
    case $ans in
     1)
    	fn_vdb
    	submenu
    	;;
    2)
    	fn_sdb
    	submenu
    	;;
    3)
        mainmenu
        ;;
    0)
        fn_bye
        ;;
    *)
        fn_fail
        ;;
    esac
}

mainmenu() {
    echo -ne "
$(magentaprint 'MAIN MENU')
$(greenprint '1)') SUB-MENU
$(redprint '0)') Exit
Choose an option:  "
    read -r ans
    case $ans in
    1)
        submenu
        mainmenu
        ;;
    0)
        fn_bye
        ;;
    *)
        fn_fail
        ;;
    esac
}

mainmenu
