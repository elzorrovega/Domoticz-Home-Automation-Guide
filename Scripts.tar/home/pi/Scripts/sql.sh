#!/bin/bash

# sqlite3 hold.db 'select distinct target from hold target'
cd /home/pi/Scripts
ls *db
read -p "Enter database to review ie. base.db " base
sqlite3 "$base" '.schema'
read -p "Enter table to show " mesa
read -p "Enter max 3 columns or null to print table " col1 col2 col3
if [[ -n "$col1" && -n "$col2" && -n "$col3" ]]; then 
sqlite3 "$base" << EOS
.mode column
select "$col1", "$col2", "$col3" from "$mesa";
EOS
elif [[ -n "$col1" && -n "$col2" ]]; then
sqlite3 "$base" << EOS
.mode column
select "$col1", "$col2" from "$mesa";
EOS
elif [ -n "$col1" ]; then
sqlite3 "$base" << EOS
.mode column
select "$col1" from "$mesa";
EOS
else
sqlite3 "$base" "select * from "$mesa"";
fi
exit
