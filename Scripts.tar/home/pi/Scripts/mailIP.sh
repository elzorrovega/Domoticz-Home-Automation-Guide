#!/bin/sh
 mailreceiver=quike.cuadra@gmail.com
 today=$(date)
 #my_ip=`ifconfig | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{print $1}'`
 my_ip=`wget -q -O - checkip.dyndns.org|sed -e 's/.*Current IP Address: //' -e 's/<.*$//'`
 my_pi="Domoticz RaspberryPi has rebooted! "
 message="Your Pi has rebooted at $today. Current IP address = $my_ip"
 echo $message > message.txt
 mutt -s "${my_pi}" ${mailreceiver} < message.txt && rm message.txt
