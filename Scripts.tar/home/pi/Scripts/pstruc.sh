#!/bin/bash
#This script will sort process structure with descending order using MEM usage as key (fourth column)
#If no parameter is given then to standard output otherwise to file name. 
if [ "$#" != "1" ]; then
#	top | mawk '{if (NR < 6) print $0} END{printf("\r")}' 
	top -b -n 1 | head -n 5 
	ps aux --sort -%mem | mawk 'OFS="\t"{print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11}'

#	ps -auxf | sort -r -k 4
else
	date > "$1"
	top -b -n 1 | head -n 5 >> "$1"
	ps aux --sort -%mem | mawk 'OFS="\t"{print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11}' >> "$1"
#	ps -auxf | sort -r -k 4 >> "$1"
fi
exit
