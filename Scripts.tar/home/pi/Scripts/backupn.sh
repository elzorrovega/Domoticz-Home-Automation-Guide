#!/bin/bash
# 25/06/22
# Script backs-up the directories & files mention below.
# Using a memory stick as destination folder
#
DEST_FOLDER='/media/pi/LKingston/backup'
DEST_FILE="backup-$(date +'%F_%R').tar"
BACKUP_CMD='/bin/tar -rvf'
BACKUP_CMD2='/bin/cp -rvf'
#
# sudo /bin/rm $DEST_FOLDER/$DEST_FILE.gz
# $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /etc/app1/file1.conf
#
### Colors ##
ESC=$(printf '\033') RESET="${ESC}[0m" BLACK="${ESC}[30m" RED="${ESC}[31m"
GREEN="${ESC}[32m" YELLOW="${ESC}[33m" BLUE="${ESC}[34m" MAGENTA="${ESC}[35m"
CYAN="${ESC}[36m" WHITE="${ESC}[37m" DEFAULT="${ESC}[39m"

### Color Functions ##

greenprint() { printf "${GREEN}%s${RESET}\n" "$1"; }
blueprint() { printf "${BLUE}%s${RESET}\n" "$1"; }
redprint() { printf "${RED}%s${RESET}\n" "$1"; }
yellowprint() { printf "${YELLOW}%s${RESET}\n" "$1"; }
magentaprint() { printf "${MAGENTA}%s${RESET}\n" "$1"; }
cyanprint() { printf "${CYAN}%s${RESET}\n" "$1"; }
fn_bye() { echo "Bye bye."; exit 0; }
fn_fail() { echo "Wrong option." exit 1; }
#
fn_store ()
{
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Desktop
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Documents
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Downloads
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Music
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Pictures
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Public
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Scripts
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Sound
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/store
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Templates
sudo $BACKUP_CMD $DEST_FOLDER/$DEST_FILE /home/pi/Videos
sudo /bin/gzip $DEST_FOLDER/$DEST_FILE
sudo $BACKUP_CMD2 /home/pi/Documents/bookmarks_19_03_2023.html $DEST_FOLDER
sudo $BACKUP_CMD2 /home/pi/Documents/elzorrobookmarks.html $DEST_FOLDER
sudo $BACKUP_CMD2 /home/pi/Documents/DomoticzDiary $DEST_FOLDER
}
#
submenu() {
    echo -ne "
$(cyanprint 'SUBMENU')
$(greenprint '1)') /media/pi/LKingston/backup
$(greenprint '2)') /media/pi/Raspdrive/backup
$(greenprint '3)') /media/pi/Scandisk114G/backup
$(magentaprint '4)') Go Back to Main Menu
$(redprint '0)') Exit
Choose an option:  "
    read -r ans
    case $ans in
     1)
     	DEST_FOLDER='/media/pi/LKingston/backup'
    	fn_store
    	submenu
    	;;
    2)
    	DEST_FOLDER='/media/pi/Raspdrive/backup'
    	fn_store
    	submenu
    	;;
    3)
     	DEST_FOLDER='/media/pi/Scandisk114G/backup'
    	fn_store
    	submenu
        ;;

    4)
        mainmenu
        ;;
    0)
        fn_bye
        ;;
    *)
        fn_fail
        ;;
    esac
}

mainmenu() {
    echo -ne "
$(magentaprint 'MAIN MENU')
$(greenprint '1)') SUB-MENU
$(redprint '0)') Exit
Choose an option:  "
    read -r ans
    case $ans in
    1)
        submenu
        mainmenu
        ;;
    0)
        fn_bye
        ;;
    *)
        fn_fail
        ;;
    esac
}
mainmenu


