#!/bin/bash
# This script will calculate the %RAM memory usage for all process related to a given application.
#Assume that we have already a file with TOP 5 lines + ps -auxf format 
if [ "$#" != "2" ]; then
 	echo -e "Enter the file name to verify."
	echo -e "Enter task name to sum RAM %.\n"
	exit 1
else
	name="$1"
	tag="$2"
	if [ "$tag" == "all" ]; then
		cat $name | mawk -v tag="$tag" '
				BEGIN {	x=0
						y=0
				} 
				{if (NR > 6)
					{ 	x = x + $4
						y = y + $6/1000
					}
				}
				END  {
					{print "Total % RAM usage ",x}
					{print "Total RAM usage ",y}
					}
				'
	else
		cat $name | mawk -v tag="$tag" '
				BEGIN {	x=0
						y =0
				}
				/'"$tag"'/ {	x = x + $4
							y = y + $6/1000
						}
				END  {
					{print "Total ", tag " % RAM usage ",x}
					{print "Total ", tag " RAM usage ", y}
					}
				'
	fi
fi

