#!/usr/bin/env bash
cd /home/pi/store
sudo docker pull smeagolworms4/mqtt-explorer
sudo docker run -p 4000:4000 -v$(pwd)/config:/mqtt-explorer/config smeagolworms4/mqtt-explorer
#
