#!/bin/bash
# Ensure that Domotics is up and running
#
sudo service domoticz.sh stop
sudo service domoticz.sh start
sudo service domoticz.sh status
#
echo "Then start Monit again"

sudo /etc/init.d/monit start
