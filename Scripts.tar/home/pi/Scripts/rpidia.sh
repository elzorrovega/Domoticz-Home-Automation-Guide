#!/bin/bash
#Read RPI uptime and temperature
#Use top for general overview of CPU LOAD % RAM usage
#Use head command is extracts the first 5 lines
#Must set decimal separator to decimal so that mawk works properly
#MAWK CVS format output: rpiuptime, rpicpu(5min), rpiRAM, rpiSWAP, rpitemp
rpiup=$(uptime -s)
temp=$(vcgencmd measure_temp | egrep -o '[0-9]*\.[0-9]*')
ssize=$(egrep CONF_SWAPSIZE /etc/dphys-swapfile | egrep -o '[0-9]*')
#Get Swapsize in the event that swapoff -a is set
LC_ALL="C" top -b -n 1 | head -n 5 | mawk -v rpiup="$rpiup" -v temp="$temp" -v ssize=$ssize '
				BEGIN{	{printf ("%19s",rpiup)}
						{printf("%c",",")}
				}
				/load average/ {printf ("%3.1f", substr($13,1,length($13)-1)*100)}
				/load average/ {printf("%c",",")}
				/MiB Mem/ {printf ("%3.1f",$8/$4*100)}
				/MiB Mem/{printf("%c",",")}
				/MiB Swap/{printf("%3.1f",$7/ssize*100)}
				/MiB Swap/{printf("%c",",")}
				END{{printf("%3.1f\n",temp)}}
				'

