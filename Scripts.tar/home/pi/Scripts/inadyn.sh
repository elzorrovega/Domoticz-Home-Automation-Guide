#!/usr/bin/env bash
cd /home/pi/store/inadyn/inadyn-2.10.0
sudo docker run --rm -v "$PWD/inadyn.conf:/etc/inadyn.conf" inadyn:latest
#
